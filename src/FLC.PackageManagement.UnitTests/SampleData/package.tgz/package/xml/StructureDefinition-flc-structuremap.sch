<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile StructureMap
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:StructureMap/f:group/f:rule/f:target</sch:title>
    <sch:rule context="f:StructureMap/f:group/f:rule/f:target">
      <sch:assert test="count(f:extension[@url = 'http://puri.fhir.link/flc/StructureDefinition/fhir-liquid-map']) &gt;= 1">extension with URL = 'http://puri.fhir.link/flc/StructureDefinition/fhir-liquid-map': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://puri.fhir.link/flc/StructureDefinition/fhir-liquid-map']) &lt;= 1">extension with URL = 'http://puri.fhir.link/flc/StructureDefinition/fhir-liquid-map': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
